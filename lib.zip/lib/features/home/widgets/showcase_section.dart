import 'package:flutter/material.dart';
import 'product_card.dart';
import '../../../screens/catalog_screen.dart';

class ShowcaseSection extends StatelessWidget {
  const ShowcaseSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              const Text(
                'Сегодня на витрине',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Color(0xff2D2621),
                  fontFamily: 'Georgia',
                ),
              ),
              const Spacer(),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const CatalogScreen()),
                  );
                },
                child: const Row(
                  children: [
                    Text(
                      'Все',
                      style: TextStyle(
                        color: Color(0xff7B4A22),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Georgia',
                      ),
                    ),
                    SizedBox(width: 3),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 10,
                      color: Color(0xff7B4A22),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 12),

        IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: const [
              Expanded(
                child: ProductCard(
                  image: 'assets/images/bread_chiabatta.jpg',
                  title: 'Чиабатта',
                  price: 450,
                  badge: 'ХИТ',
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: ProductCard(
                  image: 'assets/images/cake_signature.jpg',
                  title: 'Круассан сливочный',
                  price: 290,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 10),

        IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: const [
              Expanded(
                child: ProductCard(
                  image: 'assets/images/bread_country.jpg',
                  title: 'Хлеб деревенский на закваске',
                  price: 390,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: ProductCard(
                  image: 'assets/images/dessert_tart.jpg',
                  title: 'Наполеон',
                  price: 420,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
