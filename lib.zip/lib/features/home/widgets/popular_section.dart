import 'package:flutter/material.dart';

class PopularSection extends StatelessWidget {
  const PopularSection({super.key});

  @override
  Widget build(BuildContext context) {
    final products = [
      const _PopularItem(
        image: 'assets/images/dessert_eclair.jpg',
        title: 'Эклер',
        price: 210,
      ),
      const _PopularItem(
        image: 'assets/images/dessert_dacquoise.jpg',
        title: 'Дакуаз',
        price: 260,
      ),
      const _PopularItem(
        image: 'assets/images/dessert_lemon_basil.jpg',
        title: 'Тарт лимон-б...',
        price: 320,
      ),
      const _PopularItem(
        image: 'assets/images/bread_chiabatta.jpg',
        title: 'Чиабатта',
        price: 250,
      ),
      const _PopularItem(
        image: 'assets/images/bread_classic.jpg',
        title: 'Булочка сдобная',
        price: 120,
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: const [
              Text(
                "Популярное",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Color(0xff2D2621),
                  fontFamily: 'Georgia',
                ),
              ),
              Spacer(),
              Text(
                "Все",
                style: TextStyle(
                  color: Color(0xff7B4A22),
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Georgia',
                ),
              ),
              SizedBox(width: 3),
              Icon(Icons.arrow_forward_ios, size: 10, color: Color(0xff7B4A22)),
            ],
          ),
        ),

        const SizedBox(height: 8),

        SizedBox(
          height: 114,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: products.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, index) => products[index],
          ),
        ),
      ],
    );
  }
}

class _PopularItem extends StatelessWidget {
  final String image;
  final String title;
  final int price;

  const _PopularItem({
    required this.image,
    required this.title,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 76,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              width: 76,
              height: 76,
              child: Image.asset(image, fit: BoxFit.cover),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              color: Color(0xff2D2621),
              fontFamily: 'Georgia',
            ),
          ),
          Text(
            "$price ₽",
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: Color(0xff7B4A22),
              fontFamily: 'Georgia',
            ),
          ),
        ],
      ),
    );
  }
}
