import 'package:flutter/material.dart';

class HomeHeader extends StatelessWidget {
  const HomeHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;

    const double photoHeight = 150;
    const double searchBarOverlap = 20;
    const double searchBarHeight = 46;
    const double bottomGap = 8;

    return SizedBox(
      height: top + photoHeight - searchBarOverlap + searchBarHeight + bottomGap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          SizedBox(
            width: double.infinity,
            height: top + photoHeight,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset(
                    'assets/images/hero_banner.jpg',
                    fit: BoxFit.cover,
                  ),
                ),

                Positioned(
                  left: 0,
                  top: 0,
                  child: Container(
                    width: 260,
                    height: top + photoHeight,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          Colors.white.withOpacity(.55),
                          Colors.white.withOpacity(0),
                        ],
                      ),
                    ),
                  ),
                ),

                Positioned(
                  left: 22,
                  top: top + 16,
                  right: 96,
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Доброе утро,\nСергей!',
                        style: TextStyle(
                          color: Color(0xFF3E2517),
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                          height: 1.1,
                          fontFamily: 'Georgia',
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Испечено с любовью\nдля Вас.',
                        style: TextStyle(
                          color: Color(0xFF4A3226),
                          fontSize: 13,
                          height: 1.2,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Georgia',
                        ),
                      ),
                    ],
                  ),
                ),

                Positioned(
                  right: 22,
                  top: top + 6,
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.94),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.10),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.person_rounded,
                      size: 15,
                      color: Color(0xff7B4A22),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Positioned(
            left: 18,
            right: 18,
            top: top + photoHeight - searchBarOverlap,
            child: Container(
              height: searchBarHeight,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(23),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.10),
                    blurRadius: 16,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: const Row(
                children: [
                  SizedBox(width: 18),
                  Icon(Icons.search, color: Color(0xff8C837D), size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Поиск хлеба, тортов, десертов...',
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xff8C837D),
                        fontFamily: 'Georgia',
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  SizedBox(width: 14),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
