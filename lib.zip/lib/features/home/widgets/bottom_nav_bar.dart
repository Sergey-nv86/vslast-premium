import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class PremiumBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const PremiumBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).padding.bottom;

    return Container(
      padding: EdgeInsets.only(top: 8, bottom: bottomInset > 0 ? bottomInset : 8),
      decoration: BoxDecoration(
        color: const Color(0xFFFDFBF8),
        border: Border(
          top: BorderSide(color: Colors.black.withOpacity(.06), width: 1),
        ),
      ),
      child: Row(
        children: [
          _item(icon: 'assets/icons/home.svg', label: 'Главная', index: 0),
          _item(icon: 'assets/icons/catalog.svg', label: 'Каталог', index: 1),
          _item(icon: 'assets/icons/premium.svg', label: 'Карта', index: 2),
          _item(
            icon: 'assets/icons/favorite.svg',
            label: 'Избранное',
            index: 3,
          ),
          _item(icon: 'assets/icons/add.svg', label: 'Корзина', index: 4),
        ],
      ),
    );
  }

  Widget _item({
    required String icon,
    required String label,
    required int index,
  }) {
    final selected = currentIndex == index;

    return Expanded(
      child: InkWell(
        onTap: () => onTap(index),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SvgPicture.asset(
              icon,
              width: 20,
              height: 20,
              colorFilter: ColorFilter.mode(
                selected ? const Color(0xFF7B4A22) : const Color(0xFF9A948E),
                BlendMode.srcIn,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 9.5,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected
                    ? const Color(0xFF7B4A22)
                    : const Color(0xFF9A948E),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
