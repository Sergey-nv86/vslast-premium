import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/cart_provider.dart';
import '../../../screens/cart_screen.dart';
import '../../../widgets/cart_summary_bar.dart';
import '../widgets/home_header.dart';
import '../widgets/popular_section.dart';
import '../widgets/showcase_section.dart';

/// Главная. Раньше весь экран был одним SingleChildScrollView — блок
/// "Сегодня на витрине" рос вместе с карточками и всё уезжало вниз.
/// Теперь верстка — Column с Expanded вокруг "Сегодня на витрине": сам
/// экран целиком помещается в высоту устройства, а прокручивается только
/// "Сегодня на витрине" (вертикально, внутри своей области). "Популярное"
/// как и раньше — горизонтальный скролл, но теперь занимает фиксированное
/// место внизу, а не "плавает" по общей длине страницы.
///
/// Плашка "Перейти в корзину" — тот же CartSummaryBar, что и в «Каталоге».
/// Раньше она была Positioned прямо поверх "Популярное" и при добавлении
/// товара наезжала на карточки снизу, закрывая часть ряда — визуально это
/// выглядело как "пустая часть экрана" (ряд карточек внезапно "обрезался"
/// плашкой). Теперь CartSummaryBar — обычный элемент Column в самом низу,
/// он появляется через AnimatedSize и просто сдвигает контент вверх,
/// ничего не перекрывая.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _openCart(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const CartScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return SafeArea(
      top: false,
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const HomeHeader(),
          const SizedBox(height: 12),
          const Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 18),
              child: ShowcaseSection(),
            ),
          ),
          const SizedBox(height: 6),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 18),
            child: PopularSection(),
          ),
          const SizedBox(height: 8),
          AnimatedSize(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            alignment: Alignment.bottomCenter,
            child: cart.isEmpty
                ? const SizedBox(width: double.infinity)
                : Padding(
                    padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
                    child: CartSummaryBar(
                      itemsCount: cart.totalCount,
                      totalSum: cart.totalSum,
                      onTap: () => _openCart(context),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
